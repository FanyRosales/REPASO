package com.davidchura.sistema1232.content

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.davidchura.sistema1232.R
import com.davidchura.sistema1232.ui.theme.Sistema1232Theme
import org.json.JSONArray
import java.text.DecimalFormat

class ProductsActivity : ComponentActivity() {
     var nombre = ""
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bundle = intent.extras //Asi se recuperan los datos enviados
        //a este activity mediante un Intent
        val idcategoria = bundle?.getString("idcategoria")
        nombre = bundle!!.getString("nombre").toString()
        //Así se recuperan los datos encapsulados en el bundle
        readService(idcategoria)
        enableEdgeToEdge()

    }

    private fun readService(idcategoria: String?) {
        val queue = Volley.newRequestQueue(this)
        val url = "https://servicios.campus.pe/productos.php?idcategoria=$idcategoria"
        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->
                Log.d("VOLLEY", response)
                fillArray(response)
            },
            { })
        queue.add(stringRequest)
    }
    private fun fillArray(response: String) {
        val jsonArray = JSONArray(response)
        //Se esta traduciendo ls datos de texto simple a un JSONArray
        val arrayList = ArrayList<HashMap<String, String>>()
        for (i in 0 until jsonArray.length()) {
            val idproducto = jsonArray.getJSONObject(i).getString("idproducto")
            val nombre = jsonArray.getJSONObject(i).getString("nombre")
            val precio = jsonArray.getJSONObject(i).getString("precio")
            val imagenchica = jsonArray.getJSONObject(i).getString("imagenchica")
            val preciorebajado = jsonArray.getJSONObject(i).getString("preciorebajado")
            val hashMap = HashMap<String, String>()
            hashMap["idproducto"] = idproducto
            hashMap["nombre"] = nombre
            hashMap["precio"] = precio
            hashMap["imagenchica"] = imagenchica
            hashMap["preciorebajado"] = preciorebajado
            arrayList.add(hashMap)
        }
        drawSuppliers(arrayList)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    private fun drawSuppliers(arrayList: ArrayList<HashMap<String, String>>) {
        setContent {
            Sistema1232Theme {
                Scaffold (
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            colors = topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                titleContentColor = MaterialTheme.colorScheme.primary,
                            ),
                            title = {
                                Text(nombre)
                            }
                        )
                    },
                ){
                    Column (modifier = Modifier.padding(it)){
                        LazyVerticalGrid(columns = GridCells.Fixed(2)) {
                            items(items = arrayList){ product ->
                                Card(modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        //mostrarVentana(index)
                                    },
                                    elevation = CardDefaults.cardElevation(
                                        defaultElevation = 6.dp
                                    ),
                                    colors = CardDefaults.cardColors(
                                        containerColor = Color.White)){
                                    DrawProductItem(product)
                                }
                            }
                        }
                    }
                }
            }
        }
    }


}

@Composable
private fun DrawProductItem(product: HashMap<String, String>) {


    var imagePath = "https://servicios.campus.pe/imagenes/nofoto.jpg"
    if(product["imagenchica"] != "null"){
        imagePath = "https://servicios.campus.pe/" +
                product["imagenchica"].toString()
    }
    AsyncImage( model = imagePath, contentDescription = null)

    Text(text = product["nombre"].toString())
    val precio = product["precio"].toString().toFloat()
    val preciorebajado = product["preciorebajado"].toString().toFloat()
    if (preciorebajado > 0){
        val porcentajedescuento = (1 - preciorebajado/precio) * 100
        Text(text = "S/ %.2f".format(preciorebajado))
        Text(text = "S/ %.2f".format(precio),
            textDecoration = TextDecoration.LineThrough)
        Text(text = "%.0f".format(porcentajedescuento) + "%")
    }else{
        Text(text = "S/ %.2f".format(precio))
    }
}