package com.davidchura.sistema1232.content

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.davidchura.sistema1232.ui.theme.Sistema1232Theme
import org.json.JSONArray

class EmployeesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readService()
        enableEdgeToEdge()

    }

    private fun readService() {
        val queue = Volley.newRequestQueue(this)
        val url = "https://servicios.campus.pe/empleados.php"
        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->
                Log.d("VOLLEY", response)
                fillArray(response)
            },
            { })
        queue.add(stringRequest)
    }

    private fun fillArray(response: String) {
        val jsonArray = JSONArray(response)
        //Se esta traduciendo ls datos de texto simple a un JSONArray
        val arrayList = ArrayList<HashMap<String, String>>()
        for (i in 0 until jsonArray.length()) {
            val apellidos = jsonArray.getJSONObject(i).getString("apellidos")
            val nombres = jsonArray.getJSONObject(i).getString("nombres")
            val cargo = jsonArray.getJSONObject(i).getString("cargo")
            val foto = jsonArray.getJSONObject(i).getString("foto")
            val hashMap = HashMap<String, String>()
            hashMap["apellidos"] = apellidos
            hashMap["nombres"] = nombres
            hashMap["cargo"] = cargo
            hashMap["foto"] = foto
            arrayList.add(hashMap)
        }
        drawSuppliers(arrayList)
    }

    private fun drawSuppliers(arrayList: ArrayList<HashMap<String, String>>) {
        setContent {
            Sistema1232Theme {
                Column {
                    LazyRow {
                        items(items = arrayList) { employee ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .border(
                                        width = 1.dp, color = Color.Gray,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(16.dp)
                            ) {
                                DrawEmployee(employee)
                            }
                        }//Items
                    } //LazyColumn
                }
            }
        }
    }
}
@Composable
fun DrawEmployee(employee: HashMap<String, String>) {
    AsyncImage(
        model = "https://servicios.campus.pe/fotos/" + employee["foto"].toString(),
        contentDescription = null
    )
    Text(
        text = employee["nombres"].toString(),
        style = MaterialTheme.typography.titleLarge
    )
    Text(
        text = employee["apellidos"].toString(),
        style = MaterialTheme.typography.titleMedium
    )
    Text(text = employee["cargo"].toString())
}