package com.davidchura.sistema1232.content

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.davidchura.sistema1232.content.ui.theme.Sistema1232Theme
import org.json.JSONArray

class StoreActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readService()
        enableEdgeToEdge()

    }

    private fun readService() {
        val queue = Volley.newRequestQueue(this)
        val url = "https://servicios.campus.pe/categorias.php"
        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->
                Log.d("VOLLEY", response)
                fillArray(response)
            },
            { })
        queue.add(stringRequest)
    }

    private fun fillArray(response: String) {
        val jsonArray = JSONArray(response)
        //Se esta traduciendo ls datos de texto simple a un JSONArray
        val arrayList = ArrayList<HashMap<String, String>>()
        for (i in 0 until jsonArray.length()) {
            val idcategoria = jsonArray.getJSONObject(i).getString("idcategoria")
            val nombre = jsonArray.getJSONObject(i).getString("nombre")
            val descripcion = jsonArray.getJSONObject(i).getString("descripcion")
            val foto = jsonArray.getJSONObject(i).getString("foto")
            val total = jsonArray.getJSONObject(i).getString("total")
            val hashMap = HashMap<String, String>()
            hashMap["idcategoria"] = idcategoria
            hashMap["nombre"] = nombre
            hashMap["descripcion"] = descripcion
            hashMap["foto"] = foto
            hashMap["total"] = total
            arrayList.add(hashMap)
        }
        drawSuppliers(arrayList)
    }

    private fun drawSuppliers(arrayList: ArrayList<HashMap<String, String>>) {
        setContent {
            com.davidchura.sistema1232.ui.theme.Sistema1232Theme {
                Column {
                    LazyColumn {
                        items(items = arrayList) { category ->
                            Box (modifier = Modifier.clickable { 
                                selectCategory(category)
                            }){
                                DrawCategoryItem(category)
                            }
                        }//Items
                    } //LazyColumn
                }
            }
        }
    }

    private fun selectCategory(category: HashMap<String, String>) {
        //category es el objeto categoría seleccionada
        val bundle = Bundle().apply {//Empaqueta los datos que se enviarán
            //a un nuevo activity
            putString("idcategoria", category["idcategoria"])
            putString("nombre", category["nombre"])
        }
        val intent = Intent(this, ProductsActivity::class.java)
        intent.putExtras(bundle)//Así se envian los datos encapsulados
        // en la clase bundle
        startActivity(intent)
    }
}

@Composable
fun DrawCategoryItem(category: java.util.HashMap<String, String>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .border(
                width = 1.dp, color = Color.Gray,
                shape = RoundedCornerShape(4.dp)
            )
            .padding(16.dp)
    ) {
        Text(
            text = category["idcategoria"].toString(),
            style = MaterialTheme.typography.titleLarge
        )
        Text(
            text = category["nombre"].toString(),
            style = MaterialTheme.typography.titleMedium
        )
        Text(text = category["descripcion"].toString())
        Text(text = "Total :" + category["total"].toString())
    }
}